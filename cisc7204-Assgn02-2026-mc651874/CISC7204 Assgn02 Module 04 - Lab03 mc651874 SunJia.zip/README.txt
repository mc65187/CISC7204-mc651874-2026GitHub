CISC7204 Assignment 02 - Module 04 Lab03
Add Interactivity: User Input and Callbacks
Student: mc651874 SunJia
====================================================

FILES
-----
1. dash_interactivity.py            - main app: average monthly arrival delay by input year
2. dash_interactivity_barplot.py    - practice task: total flights per destination state
                                       split by reporting airline, for the input year

HOW TO RUN (each app on its own terminal)
----------------------------------------
Environment: Python 3.9 (py39 conda env) with pandas, plotly, dash installed.

1. python dash_interactivity.py          -> http://127.0.0.1:8050/
2. python dash_interactivity_barplot.py  -> http://127.0.0.1:8050/
   (run one at a time, they both use port 8050)

Stop a running app in the terminal: Ctrl+C

MAIN APP (dash_interactivity.py)
--------------------------------
Layout:
  - H1: 'Airline Performance Dashboard' (center, #503D36, font-size 40)
  - dcc.Input id='input-year' (type number, default 2010, height 50px, font-size 35)
  - dcc.Graph id='line-plot'

Callback:
  Output: line-plot.figure
  Input : input-year.value
  Graph : go.Scatter(x=Month, y=ArrDelay, mode='lines', color green),
          title 'Month vs Average Flight Delay Time', xaxis 'Month', yaxis 'ArrDelay'

Verified: server returns HTTP 200; calling the callback with year=2010 returns a
scatter line trace with 12 monthly data points (1-12).

PRACTICE APP (dash_interactivity_barplot.py)
--------------------------------------------
Theme: total number of flights to each destination state for the selected year,
       split by reporting airline.

  - H1: 'Total number of flights to the destination state split by reporting airline'
       (center, #503D36, font-size 40)
  - dcc.Input id='input-year' (same style as main app)
  - dcc.Graph id='bar-plot'

Callback:
  Output: bar-plot.figure
  Input : input-year.value
  Graph : px.bar(bar_data, x='DestState', y='Flights', color='Reporting_Airline',
                 title='Total number of flights to the destination state split by reporting airline')
  where bar_data = airline_data[airline_data['Year'] == int(year)]
                        .groupby(['DestState', 'Reporting_Airline'])['Flights'].sum().reset_index()

Verified: server returns HTTP 200; calling the callback with year=2010 returns
18 bar traces (one per reporting airline) covering 48 destination states.

VERIFICATION METHOD
-------------------
- HTTP GET  /                    -> 200
- HTTP POST /_dash-update-component with input-year.value=2010 -> returns the
  expected figure (line chart / grouped bar chart) proving the callback works.
