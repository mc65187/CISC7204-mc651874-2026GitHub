CISC7204 Assignment 02 - Module 04 Lab02
Dash Basics: HTML and Core Components
Student: mc651874 SunJia
====================================================

HOW TO RUN
----------
Environment: Python 3.9 (py39 conda env) with pandas, plotly, dash installed.

1. From a terminal, run:
     python dash_basics.py
2. Wait for the message "Dash is running on http://127.0.0.1:8050/"
3. Open a browser at http://127.0.0.1:8050/ to view the dashboard.

The dashboard shows:
  - H1 title:  "Airline On-time Performance Dashboard" (center, #503D36, font-size 50)
  - P text:    "Proportion of distance group (250 mile distance interval group) by flights." (center, #F57241)
  - dcc.Graph: pie chart of proportion of distance group by flights (500 sampled rows of airline_data.csv)

PRACTICE TASK ANSWERS
----------------------
1. Title changed from "Airline Dashboard" to "Airline On-time Performance Dashboard",
   font-size updated from 40 to 50 (see dash_basics.py, html.H1 component).
2. Saved and relaunched to confirm the updated title renders (verified via HTTP 200
   on the root endpoint and the _dash-layout response containing the new H1).
3. Stop the running app in the terminal: press Ctrl+C (or use pkill -f dash_basics.py).

STOP COMMAND (practice task 3 answer)
--------------------------------------
Ctrl+C   (in the terminal where the app is running)
