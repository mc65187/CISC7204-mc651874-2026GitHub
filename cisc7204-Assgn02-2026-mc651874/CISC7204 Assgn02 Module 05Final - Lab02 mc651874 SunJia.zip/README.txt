CISC7204 Assignment 02 - Module 05 Final Project Part 02
Creating Dashboard with Plotly and Dash
Student: mc651874 SunJia
====================================================

FILE
----
DV0101EN-Final-Assign-Part-2-Questions.py

HOW TO RUN
----------
Environment: Python 3.9 (py39 conda env) with pandas, plotly, dash, more-itertools.

1. python DV0101EN-Final-Assign-Part-2-Questions.py
   -> http://127.0.0.1:8050/
2. Stop with Ctrl+C.

DASHBOARD FEATURES
------------------
- H1 title: "Automobile Sales Statistics Dashboard" (center, #503D36, font-size 24)
- Dropdown id='dropdown-statistics':
    Yearly Statistics / Recession Period Statistics
- Dropdown id='select-year': years 1980-2023
- Callback update_input_container:
    When 'Recession Period Statistics' selected -> year dropdown disabled.
    When 'Yearly Statistics' selected -> year dropdown enabled.
- Output container id='output-container' (className='chart-grid', flex):
  4 plots in 2x2 grid.

RECESSION PERIOD STATISTICS (Recession==1):
  R_chart1: line - avg automobile sales by year over recession
  R_chart2: bar  - avg vehicles sold by vehicle type
  R_chart3: pie  - advertising expenditure share by vehicle type
  R_chart4: bar  - effect of unemployment rate on sales by vehicle type

YEARLY STATISTICS (selected year):
  Y_chart1: line - yearly avg automobile sales (whole period)
  Y_chart2: line - total monthly automobile sales for the selected year
  Y_chart3: bar  - avg vehicles sold by vehicle type in the selected year
  Y_chart4: pie  - total advertising expenditure for each vehicle in the year

SCREENSHOTS FOR EVALUATION
--------------------------
After launching the app in browser:
  - Select "Recession Period Statistics" -> screenshot as RecessionReportgraphs.png
  - Select "Yearly Statistics" and a year (e.g. 2005) -> screenshot as YearlyReportgraphs.png

VERIFICATION
------------
- App starts on http://127.0.0.1:8050/ (HTTP 200)
- Data loads from automobile-sales.csv
- Both dropdowns and output container rendered in layout
