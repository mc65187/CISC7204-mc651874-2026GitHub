CISC7204 Assignment 02 - Module 05 Practice Project Part 02
Creating Dashboards (Australia Wildfire Dashboard)
Student: mc651874 SunJia
====================================================

FILE
----
Dash_wildfire.py - dash application for wildfire summary data

HOW TO RUN
----------
Environment: Python 3.9 (py39 conda env) with pandas, plotly, dash installed.

1. python Dash_wildfire.py   -> http://127.0.0.1:8050/
2. Stop with Ctrl+C in the terminal.

COMPONENTS
----------
- H1 title: 'Australia Wildfire Dashboard' (center, #503D36, font-size 26)
- RadioItems id='region' (inline): New South Wales(NSW), Northern Territory(NT),
  Queensland(QL), South Australia(SA), Tasmania(TA), Victoria(VI), Western Australia(WA);
  default NSW
- Dropdown id='year': df.Year.unique() (2005-2020), default 2005
- Output divisions: id='plot1' (pie), id='plot2' (bar), in a flex container

CALLBACK
--------
Outputs: plot1.children, plot2.children
Inputs : region.value, year.value
- plot1: px.pie of Monthly Average Estimated_fire_area for the selected region/year
- plot2: px.bar of Monthly Average Count (pixels for presumed vegetation fires)

VERIFICATION (real server run)
------------------------------
- HTTP GET  / -> 200
- Layout contains title, region radioitems, year dropdown, plot1, plot2
- HTTP POST /_dash-update-component (region=NSW, year=2005) returns:
    plot1 -> pie figure  "NSW : Monthly Average Estimated Fire Area in year 2005"
    plot2 -> bar figure  "NSW : Average Count of Pixels for Presumed Vegetation Fires in year 2005"
